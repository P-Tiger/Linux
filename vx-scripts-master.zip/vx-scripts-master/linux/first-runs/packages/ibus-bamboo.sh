# ibus-bamboo
# Bộ gõ tiếng việt ngon trên linux
sudo add-apt-repository ppa:bamboo-engine/ibus-bamboo
sudo apt-get update
sudo apt-get install ibus-bamboo
ibus restart
