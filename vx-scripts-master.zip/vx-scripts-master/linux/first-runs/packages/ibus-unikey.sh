ibus-ubikey
sudo apt install ibus-unikey -y
ibus restart
