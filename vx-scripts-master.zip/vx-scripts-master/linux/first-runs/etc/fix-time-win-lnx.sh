#!/bin/sh
timedatectl set-local-rtc 1
timedatectl
