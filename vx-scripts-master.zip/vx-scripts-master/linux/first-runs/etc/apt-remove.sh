<<<<<<< HEAD
#!/bin/sh
sudo apt remove synaptic
sudo snap remove dotnet-sdk
sudo apt remove --purge libreoffice* -y
=======
#!/bin/sh
sudo apt remove synaptic
sudo snap remove dotnet-sdk
sudo apt-get remove --purge libreoffice* -y
>>>>>>> 9734a40e5d88e53c415142dedab2b75e54fc7772
