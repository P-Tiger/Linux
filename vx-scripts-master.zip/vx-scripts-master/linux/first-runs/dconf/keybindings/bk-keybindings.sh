dconf dump /org/gnome/desktop/wm/keybindings/ > keybindings-1.dconf
dconf dump /org/gnome/settings-daemon/plugins/media-keys/ > keybindings-2.dconf
