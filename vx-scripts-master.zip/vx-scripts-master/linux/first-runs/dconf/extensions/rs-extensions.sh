dconf load /org/gnome/shell/extensions/ < extensions.dconf
