dconf dump /org/gnome/desktop/privacy/ > privacy.dconf
