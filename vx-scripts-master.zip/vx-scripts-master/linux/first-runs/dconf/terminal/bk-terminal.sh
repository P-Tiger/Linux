dconf dump /org/gnome/terminal/ > terminal.dconf
