#!/bin/bash

###
# Reset endling of a file
###
function sed_file() {
	file=$1
	[ -f $file ] && { sed -i -e 's/\r$//' $file && echo "Fixed: ${file}!\n" } || echo "File does not exists!"
}


###
# Main
###
ls -d -1 -d */
read -p "> ENTER DIRECTORY: "
dir=$REPLY

sed_file $dir
exit 1
