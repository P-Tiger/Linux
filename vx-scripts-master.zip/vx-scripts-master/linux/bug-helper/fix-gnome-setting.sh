#!/bin/sh
sudo apt install gnome-control-center -y
gnome-control-center
