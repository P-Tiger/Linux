killall -3 gnome-shell
