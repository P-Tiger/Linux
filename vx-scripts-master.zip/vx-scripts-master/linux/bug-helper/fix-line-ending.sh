#!/bin/bash
###
# Reset endline of a file
###
sed_file() {
	file=$1
	[[ -f $file ]] && [[ $file == *.txt ]] &&
		sed -i -e 's/\r$//' $file && echo "File fixed: ${file}" ||
			echo "File doesn't exists!"
}

###
# Find all files in a directory to change endline style
# Recursion if reach a folder
###
sed_dir() {
	if [[ -d $1 ]]; then
		for arg in $(ls -d "${1}"*); do
			echo $arg
			if [[ -f $arg ]]; then
				sed_file $arg
			else
				sed_dir ${arg/};
			fi
		done
	fi
}


###
# Main
###
ls -1 -d */
echo "> ENTER DIRECTORY: "
read -p "${PWD}/"
dir+=$PWD/$REPLY
sed_dir $dir
exit 1

for arg in "$@"; do
	if [ -f $arg ]; then
		sed_file $arg;
	elif [ -d $arg ]; then
		sed_recursion_dir $arg
	else
		echo "[ERROR] ${arg} is not a file or a directory!"
	fi
done
