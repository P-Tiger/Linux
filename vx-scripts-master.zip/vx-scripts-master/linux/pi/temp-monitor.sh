\
#!/bin/bash

echo "$(date) @ $(hostname)"
printf "%-15s%5s\n" "TimeSTAMP" "TEMP(degC)"
printf "%20s\n" "---------------------"

while true
do
	temp=$(vcgencmd measure_temp | egrep -o '[0-9]*\.[0-9]*')
	timestamp=$(date +'%s')
	echo -ne "\r"
	printf "%-15x%5s" "$timestamp" "$temp"
	sleep 1
done
