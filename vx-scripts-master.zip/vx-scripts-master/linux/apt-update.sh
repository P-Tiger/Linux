#!/bin/bash

sudo apt update -y && sudo apt dist-upgrade -y && sudo apt upgrade -y && sudo apt autoclean -y && sudo apt autoremove -y
