#!/bin/bash

echo #NHẬT KÝ CHƠI NGU TRONG NGÀY

echo # Cài đặt một shell mới và đặt shell đó làm mặc định
echo "sudo apt install zsh"
echo "sudo chsh -s /bin/zsh"
echo "sudo apt remove zsh"

echo # Gỡ bỏ shell mặc định nhưng
echo # Không sửa lại default shell
echo # Dùng rất ổn định và đẹp trai
echo # Khỏi động lại
echo # Mọi việc rất ổn cho đến khi ubuntu
echo # nạp shell default là zsh (đã bị xóa trước đó)
echo # không nạp được ubuntu hoàn chỉnh.
echo # ==> Banh mỏ IZ REAL

echo # Cách fix
echo # Vào ubuntu recovery mode
echo # Khởi động root terminal
echo # cài đặt lại zsh (cho chắc ăn)
echo # chạy lệnh set default terminal cho user voxva và root
echo "usemode --shell /bin/bash voxva"
echo "chsh --shell /bin/bash root"

echo # Khởi động lại và tận hưởng :(

echo # Pha chơi ngu ngày 6/11/2019
