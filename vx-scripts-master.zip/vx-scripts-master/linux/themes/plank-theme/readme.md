# install plank
sudo apt install plank

# install plank theme
extrack this folder to .local/share/plank/themes
then change in plank setting: Ctrl + Click in to plank dock
