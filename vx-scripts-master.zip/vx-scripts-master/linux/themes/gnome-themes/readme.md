tar xvf Os-Catalina-Night.tar.xz
sudo mv Os-Ca... /usr/share/icons

Open Gnome Tweak
