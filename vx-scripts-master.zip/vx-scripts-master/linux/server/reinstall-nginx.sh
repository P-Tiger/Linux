sudo apt purge nginx nginx-common nginx-full  
sudo apt install nginx
