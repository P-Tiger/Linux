CREATE DATABASE wordpress DEFAULT CHARACTER SET utf8 COLLATE utf8_unicode_ci;

SELECT user,authentication_string,plugin,host FROM mysql.user;

