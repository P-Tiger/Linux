#!/bin/sh
sudo apt install mysql-server -y
sudo mysql_secure_installation
