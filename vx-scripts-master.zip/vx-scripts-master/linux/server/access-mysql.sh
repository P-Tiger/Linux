mysql -u root -p
