#!/bin/sh
sudo apt install php-fpm php-mysql -y
sudo nano /etc/nginx/sites-available/hieusite.com
