#!/bin/bash

sudo rm -f /var/www/wordpress/.maintenance
echo fixed
