#!/bin/sh
sudo adduser kyts
sudo usermod -aG sudo kyts
