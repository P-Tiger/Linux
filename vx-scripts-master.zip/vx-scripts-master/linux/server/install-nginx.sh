#!/bin/sh
sudo apt update
sudo apt install nginx -y
sudo ufw app list
sudo ufw allow 'Nginx FULL'
sudo ufw allow 'Nginx HTTP'
sudo ufw allow 'Nginx HTTPS'
sudo ufw status
