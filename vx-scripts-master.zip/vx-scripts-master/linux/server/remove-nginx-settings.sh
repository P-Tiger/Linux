#!/bin/sh
sudo rm -r /usr/share/nginx
sudo rm -r /etc/nginx
sudo rm -r /var/www/html
