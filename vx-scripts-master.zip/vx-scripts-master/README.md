# vx-scripts

Repository này chứa các scripts tự động hóa các thao tác cài đặt, cập nhật, thiết lập môi trường, v.v...
- Hoạt động trên: **Linux.Ubuntu**, Windows, MacOSX.
