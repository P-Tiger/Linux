dconf load /org/gnome/terminal/ < terminal.dconf
