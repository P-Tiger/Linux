dconf load /org/gnome/desktop/privacy/ < privacy.dconf
