dconf load /org/gnome/desktop/wm/keybindings/ < keybindings-1.dconf
dconf load /org/gnome/settings-daemon/plugins/media-keys/ < keybindings-2.dconf
