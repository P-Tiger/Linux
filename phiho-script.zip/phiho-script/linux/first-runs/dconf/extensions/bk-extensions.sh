dconf dump /org/gnome/shell/extensions/ > extensions.dconf
