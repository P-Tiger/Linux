dconf load /org/gnome/gedit/preferences/editor/ < gedit.dconf
