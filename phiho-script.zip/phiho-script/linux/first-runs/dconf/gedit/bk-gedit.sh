dconf dump /org/gnome/gedit/preferences/editor/ > gedit.dconf
