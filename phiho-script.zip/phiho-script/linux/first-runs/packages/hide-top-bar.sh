sudo apt install gnome-shell-extension-autohidetopbar
